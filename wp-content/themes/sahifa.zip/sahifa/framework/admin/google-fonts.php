<?php
$google_api_output='
	[
		{
			"family": "Tahoma",
			"variants": [
				"non-google"
			]
		},
				{
			"family": "IRANSansWebFaNum_Bold",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "IRANSansWebFaNum_Medium",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "IRANSansWebFaNum_Light",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "IRANSansWebFaNum_UltraLight",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "IRANSansWebFaNum",
			"variants": [
				"non-google"
			]
		},
		
		
		
		{
			"family": "abzarwp-BeirutLtX3",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-FarsiSimple",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-HeritageTwo",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-LinerScreen",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-ThameenDemi",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-TunisiaBold",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-TVBold",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-Flow",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-FlowBold",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-TwoBold",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-TwoLight",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-TwoMedium",
			"variants": [
				"non-google"
			]
		},{
			"family": "abzarwp-Abasan",
			"variants": [
				"non-google"
			]
		},{
			"family": "abzarwp-Afsoon",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-Aref",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-Arshia",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-Ekhlass",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-Talat",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-TitrDF",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BBadr",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BBaran",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BBardiya",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BBCNassim",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BCompset",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BDavat",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BElham",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BEsfehanBold",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BFantezy",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BFarnaz",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BFerdosi",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BHoma",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BJadidBold",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BJalal",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BKoodakBold",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BKourosh",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BLotus",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BMehrBold",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BMitra",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BMorvarid",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BNarm",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BNasimBold",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BNazanin",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BRoya",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BShiraz",
			"variants": [
				"non-google"
			]
		},{
			"family": "abzarwp-BSinaBold",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BTabassom",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BTehran",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BTitrBold",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BTitrTGEBold",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BTraffic",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BVahidBold",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BYagut",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BYas",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BYekan",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BZar",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-BZiba",
			"variants": [
				"non-google"
			]
		},{
			"family": "abzarwp-Casablanca",
			"variants": [
				"non-google"
			]
		},{
			"family": "abzarwp-Rezvan",
			"variants": [
				"non-google"
			]
		},{
			"family": "abzarwp-Shams",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-frutiger",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-Naskh",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-Kufi",
			"variants": [
				"non-google"
			]
		},
		{
			"family": "abzarwp-Silicon",
			"variants": [
				"non-google"
			]
		}
	]
';
?>